print([[
	Welcome to Jellyfish!

This is a custom UI for Calamari-M developed by theLMGN.
The three tabs are all the features Jellyfish has in 3
main sections:
    - Editor: This is where you can create and run your
              own scripts. The big area is the code
              editor, and the play bottom in the bottom
              right will run the code currently inside
              the editor. Currently, these changes are
              not saved and will be cleared when you
              close Jellyfish.
    - Tools:  This is where you can perform some quick
              actions like setting your walk speed and
              gravity. You can also enable the Jellyfish
              window staying on top of all other windows
    - Scripts:This is where your scripts library is
              stored. You can search, edit and most
              importantly, run the scripts in your
              Documents/Jellyfish/Scripts folder. The
              modifications in the script preview are
              NOT saved, and switching away from that
              script will reset the changed back to the
              contents with in the file.
]])
