local config = {
	-- characters will have an animated preview, more reliable but uses more cpu
	["CharacterPreview"] = true,
	-- if false clicking will instantly spectate that person, if true it fly the camera over
	["TweenBetween"] = true,
}




--  // FileName: rn3_SpectationUI.lua
--	// Written by: theLMGN
--	// Description: Script for allowing users to spectate others.
local parent = game.Players.LocalPlayer.PlayerGui
local gui = Instance.new("ScreenGui",parent)
pcall(function()
	gui.Parent = game.CoreGui
	parent = game.CoreGui
end)
if parent:FindFirstChild("radon_SpectationUI") then parent.radon_SpectationUI:Destroy() end
gui.Name = "radon_SpectationUI"

local mainFrame = Instance.new("ScrollingFrame",gui)
mainFrame.Size = UDim2.new(0,380,0,400)
mainFrame.Position = UDim2.new(0,0,1,-400)
mainFrame.BackgroundTransparency = 0.5
mainFrame.BackgroundColor3 = Color3.new(0,0,0)
mainFrame.BorderSizePixel = 0
mainFrame.ScrollBarThickness = 1
local listLayout = Instance.new("UIListLayout",mainFrame)
listLayout.FillDirection = Enum.FillDirection.Vertical
listLayout.SortOrder = Enum.SortOrder.Name

local attribution = Instance.new("TextLabel", mainFrame)
attribution.Text = "scripted by theLMGN#4444"
attribution.Font = Enum.Font.SourceSans
attribution.TextSize = 11
attribution.BackgroundTransparency = 1
attribution.Size = UDim2.new(1,0,0,12)
attribution.TextColor3 = Color3.new(1,1,1)
attribution.Name = "zzzzzzzzzzzzzzzzzzzzzzzzAttribution"

local closeBtn = Instance.new("TextButton",gui)
closeBtn.Size = UDim2.new(0,40,0,40)
closeBtn.Position = UDim2.new(0,0,1,-440)
closeBtn.BackgroundTransparency = 0.5
closeBtn.BackgroundColor3 = Color3.new(0,0,0)
closeBtn.TextColor3 = Color3.new(1,1,1)
closeBtn.Text = "v"
closeBtn.Name = "closeBtn"
closeBtn.TextScaled = true

closeBtn.MouseButton1Click:Connect(function()
	if mainFrame.Position.Y.Offset == -400 then
		mainFrame:TweenPosition(UDim2.new(0,0,1,0))
		closeBtn:TweenPosition(UDim2.new(0,0,1,-40))
		closeBtn.Text = "📷"
		wait(1)
		for i,v in pairs(mainFrame:GetChildren()) do if v:IsA("TextButton") then v:Destroy() end end
	elseif mainFrame.Position.Y.Offset == 0 then
		mainFrame:TweenPosition(UDim2.new(0,0,1,-400))
		closeBtn:TweenPosition(UDim2.new(0,0,1,-440))
		closeBtn.Text = "v"
		fill()
	end
end)

local vpc = Instance.new("Camera") 
vpc.CFrame =  CFrame.Angles(0, math.rad(180),0) + Vector3.new(0, 1.5, -3)

local tween = false 


function createButton(player)
	local btn = Instance.new("TextButton",mainFrame)
	btn.Size = UDim2.new(1,-80,0,40)
	btn.BorderSizePixel = 0
	btn.Name = player.Name
	if player.Name == game.Players.LocalPlayer.Name then
		btn.Name = "aaaaaaaaaaaaaaa"..player.Name
		btn.Size = UDim2.new(1,0,0,45)
	end
	btn.Text = "    " .. player.Name
	btn.TextScaled = true
	btn.BackgroundTransparency = 0.75
	btn.BackgroundColor3 = Color3.new(0,0,0)
	btn.TextColor3 = Color3.new(1,1,1)
	btn.Font = Enum.Font.Gotham
	btn.TextXAlignment = Enum.TextXAlignment.Left
	if config["CharacterPreview"] then
		succ = pcall(function()
			local vpf = Instance.new("ViewportFrame",btn)
			vpf.BackgroundTransparency = 1
			vpf.Size = UDim2.new(0,40,0,40)
			vpf.CurrentCamera = vpc
			player.Character.Archivable = true
			local c = player.Character:Clone()
			c.Name = ""
			player.Character.Archivable = false
			local wm = Instance.new("WorldModel",vpf)
			c.Parent = wm
			c.HumanoidRootPart.CFrame = CFrame.new(0,0,0)
		end)
	end
	if  (not config["CharacterPreview"]) and not succ then
		local vpf = Instance.new("ImageLabel",btn)
		vpf.BackgroundTransparency = 1
		vpf.Size = UDim2.new(0,40,0,40)
		vpf.Image = "rbxthumb://type=AvatarHeadShot&id=" .. player.CharacterAppearanceId .. "&w=48&h=48"
	end
	btn.MouseButton1Click:Connect(function()
		local cam = game.Workspace.CurrentCamera 
		if config["TweenBetween"] then
			local succe = pcall(function()
				if tween then
					tween:Pause()
				end
				local ncframe = player.Character.HumanoidRootPart.CFrame:ToWorldSpace(cam.CFrame - cam.CameraSubject.Parent.HumanoidRootPart.Position)
				local distance = (cam.CFrame.Position - ncframe.Position).Magnitude
				print(distance)
				if distance < 0.001 then return end 
				cam.CameraType = Enum.CameraType.Scriptable
				tween = game.TweenService:Create(cam,TweenInfo.new(distance / 150), {CFrame = ncframe})
				tween:Play()
				
				tween.Completed:Connect(function()
					cam.CameraType = Enum.CameraType.Custom
					cam.CameraSubject = player.Character.Humanoid
				end)
			end)
		end
		if config["TweenBetween"] == false or succe == false then
			cam.CameraType = Enum.CameraType.Custom
			cam.CameraSubject = player.Character.Humanoid
			return
		end
		
	end)
	if player.Name == game.Players.LocalPlayer.Name then return end 
	local goBtn = Instance.new("ImageButton",btn)
	goBtn.Size = UDim2.new(0,40,0,40)
	goBtn.Position = UDim2.new(1,0,0,0)
	goBtn.BorderSizePixel = 0
	goBtn.Name = "GoBtn"
	goBtn.BackgroundTransparency = 0.75
	goBtn.BackgroundColor3 = Color3.new(0,0,0)
	goBtn.Image = "rbxassetid://3926307971"
	goBtn.ScaleType = Enum.ScaleType.Stretch
	goBtn.ImageRectOffset = Vector2.new(924,4)
	goBtn.ImageRectSize = Vector2.new(36,36)
	goBtn.MouseButton1Click:Connect(function()
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = player.Character.HumanoidRootPart.CFrame
	end)

	local lKick = Instance.new("ImageButton",btn)
	lKick.Size = UDim2.new(0,40,0,40)
	lKick.Position = UDim2.new(1,40,0,0)
	lKick.BorderSizePixel = 0
	lKick.Name = "lKick"
	lKick.BackgroundTransparency = 0.75
	lKick.BackgroundColor3 = Color3.new(0,0,0)
	lKick.Image = "rbxassetid://3926305904"
	lKick.ScaleType = Enum.ScaleType.Stretch
	lKick.ImageRectOffset = Vector2.new(284,4)
	lKick.ImageRectSize = Vector2.new(24,24)
	lKick.MouseButton1Click:Connect(function()
		local function callback(text)
			player:Destroy()
			player.Character:Destroy()
		end
		local bindableFunction = Instance.new("BindableFunction")
		bindableFunction.OnInvoke = callback
		
		game.StarterGui:SetCore("SendNotification", {
			Title = "Are you sure?";
			Text = "Remove " ..player.Name.." from the player list? This only removes from player list and this can't be undone."; 
			Callback = bindableFunction;
			Button1 = "Yes!";
		})
	end)
end

function fill()
	for i,v in pairs(mainFrame:GetChildren()) do if v:IsA("TextButton") then v:Destroy() end end
	for i,v in pairs(game.Players:GetPlayers()) do
		createButton(v)
	end
	
end
wait(1)

fill()
game.Players.PlayerAdded:Connect(fill)
game.Players.PlayerRemoving:Connect(function()
	local cam = game.Workspace.CurrentCamera 
	cam.CameraType = Enum.CameraType.Custom
	cam.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
	fill()
end)
