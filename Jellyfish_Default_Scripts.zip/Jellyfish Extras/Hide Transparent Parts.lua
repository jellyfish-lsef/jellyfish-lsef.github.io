local descs = workspace:GetDescendants()
for i,v in pairs(descs) do
    if v:IsA("BasePart") and v.CanCollide == false then
        v.Transparency = 1
    end
end