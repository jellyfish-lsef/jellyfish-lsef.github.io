local g = Instance.new("ScreenGui",game.Players.LocalPlayer.PlayerGui)
g.Name = "clickdtctors"
g.IgnoreGuiInset = true
g.ResetOnSpawn = false
local f = Instance.new("ViewportFrame",g)
f.Size = UDim2.new(1,0,1,0)
f.BackgroundTransparency = 1
f.CurrentCamera = workspace.CurrentCamera

local descs = workspace:GetDescendants()
for i,v in pairs(descs) do
    if v:IsA("ClickDetector") then
        local c = v.Parent:Clone()
        c.Parent = f
        print(c.ClassName)
    end
end