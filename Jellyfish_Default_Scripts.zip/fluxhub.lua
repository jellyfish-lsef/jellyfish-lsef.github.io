-- This script can only be executed with Fluxus.
hmjdfk()